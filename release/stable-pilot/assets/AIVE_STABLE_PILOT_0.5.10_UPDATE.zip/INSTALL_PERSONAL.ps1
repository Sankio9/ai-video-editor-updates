﻿# AIVE STABLE PILOT 0.5.10 — offline signing + Adobe UPIA install.
# Called only by the existing AIVE verified on-demand update worker.
# Never stores certificates, passwords or DOCX outside the existing local signing profile.
[CmdletBinding()]
param()
$ErrorActionPreference='Stop'
$Version='0.5.10'
$State=Join-Path $env:LOCALAPPDATA 'AIVE-Stable-Pilot'
$Root=$PSScriptRoot
$Extension=Join-Path $Root 'extension'
$Manifest=Join-Path $Extension 'CSXS\manifest.xml'
$Register=Join-Path $Root 'EXTENSION_SHA256SUMS.txt'
$Certificate=Join-Path $State 'signing\aive-stable-pilot.p12'
$PasswordFile=Join-Path $State 'signing\password.dpapi'
$Zxp=Join-Path $Root ('AIVE_STABLE_PILOT_'+$Version+'_SIGNED.zxp')
$Upia=Join-Path $env:ProgramFiles 'Common Files\Adobe\Adobe Desktop Common\RemoteComponents\UPI\UnifiedPluginInstallerAgent\UnifiedPluginInstallerAgent.exe'
function Abort([string]$message){throw ('STOP: '+$message)}
function Digest([string]$file){return (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant()}
try {
 if(Get-Process -Name 'Adobe Premiere Pro' -ErrorAction SilentlyContinue){Abort 'Inchide Premiere Pro complet inainte de instalare.'}
 if(!(Test-Path -LiteralPath $Manifest -PathType Leaf)){Abort 'Manifest lipsa.'}
 $mx=[xml](Get-Content -LiteralPath $Manifest -Raw -Encoding UTF8)
 if($mx.ExtensionManifest.ExtensionBundleId -ne 'com.aive.stable.pilot' -or $mx.ExtensionManifest.ExtensionBundleVersion -ne '0.5.10'){
  Abort 'Manifestul nu corespunde versiunii 0.5.10.'
 }
 if(!(Test-Path -LiteralPath $Register -PathType Leaf)){Abort 'Registrul SHA lipseste.'}
 $seen=@{}
 foreach($line in @(Get-Content -LiteralPath $Register -Encoding UTF8)){
  if(!$line.Trim()){continue}
  if($line -notmatch '^([a-f0-9]{64})  ([^\r\n]+)$'){Abort 'Inregistrare SHA invalida.'}
  $hash=$Matches[1];$rel=$Matches[2]
  if($rel.Contains('..') -or [IO.Path]::IsPathRooted($rel) -or $seen.ContainsKey($rel)){Abort 'Cale SHA neautorizata.'}
  $f=Join-Path $Extension ($rel.Replace('/','\'))
  if(!(Test-Path -LiteralPath $f -PathType Leaf) -or (Digest $f) -ne $hash){Abort ('Fisier modificat: '+$rel)}
  $seen[$rel]=$true
 }
 if($seen.Count -ne 11 -or @(Get-ChildItem -LiteralPath $Extension -File -Recurse).Count -ne $seen.Count){Abort 'Numar fisiere neasteptat.'}
 if(!(Test-Path -LiteralPath $Certificate -PathType Leaf) -or !(Test-Path -LiteralPath $PasswordFile -PathType Leaf)){
  Abort 'Lipseste certificatul local de semnare sau parola DPAPI. Nicio modificare.'
 }
 if(!(Test-Path -LiteralPath $Upia -PathType Leaf)){Abort 'Adobe UnifiedPluginInstallerAgent.exe lipseste.'}
 # ZXPSignCmd is not downloaded or executed from untrusted network sources.
 $candidates=@(
  (Join-Path $State 'signing\ZXPSignCmd.exe'),
  (Join-Path $State 'tools\ZXPSignCmd.exe'),
  (Join-Path $State 'ZXPSignCmd.exe'),
  (Join-Path $env:LOCALAPPDATA 'ZXPSignCmd\ZXPSignCmd.exe')
 )
 $signer=$null
 foreach($p in $candidates){if(Test-Path -LiteralPath $p -PathType Leaf){$signer=$p;break}}
 if(!$signer){$command=Get-Command 'ZXPSignCmd.exe' -ErrorAction SilentlyContinue;if($command){$signer=$command.Source}}
 if(!$signer){Abort 'ZXPSignCmd.exe nu este configurat local. Nu instalez nimic.'}
 $secret=Get-Content -LiteralPath $PasswordFile -Raw -Encoding UTF8 | ConvertTo-SecureString
 $ptr=[IntPtr]::Zero
 try{
  $ptr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
  $plaintext=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
  if(!$plaintext){Abort 'Parola locală de semnare nu poate fi citita.'}
  if(Test-Path -LiteralPath $Zxp){Remove-Item -LiteralPath $Zxp -Force}
  & $signer -sign $Extension $Zxp $Certificate $plaintext
  if($LASTEXITCODE -ne 0){Abort ('Semnarea Adobe ZXP a esuat: '+$LASTEXITCODE)}
 } finally{
  if($ptr -ne [IntPtr]::Zero){[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)}
  $plaintext=$null
 }
 if(!(Test-Path -LiteralPath $Zxp -PathType Leaf) -or (Get-Item -LiteralPath $Zxp).Length -lt 10000){Abort 'ZXP semnat nu este valid ca dimensiune.'}
 # Signing completed and local signer/certificate checks passed before invoking Adobe UPIA.
 & $Upia /install $Zxp
 if($LASTEXITCODE -ne 0){Abort ('Adobe UPIA a respins extensia: '+$LASTEXITCODE)}
 Write-Host 'PASS: Adobe UPIA a instalat AIVE STABLE PILOT 0.5.10.'
 exit 0
}catch{
 Write-Error $_.Exception.Message
 exit 1
}
