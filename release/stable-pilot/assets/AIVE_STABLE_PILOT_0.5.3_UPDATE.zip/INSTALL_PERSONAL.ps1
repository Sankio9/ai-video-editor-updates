# AIVE STABLE PILOT v0.5.3 — build + sign + verify + install via Adobe UPIA.
# Works on the personal Windows machine. Does not elevate, change registry, or enable Developer Mode.
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Ext = Join-Path $Root 'extension'
$Manifest = Join-Path $Ext 'CSXS\manifest.xml'
$SignerSource = 'https://raw.githubusercontent.com/Adobe-CEP/CEP-Resources/master/ZXPSignCMD/4.1.3/x64/ZXPSignCmd.exe'
$SignerHash = 'ffc2223167225ce61d024eb463fc5ad1a1be16133f99ef334a646f7311916c98'
$Output = Join-Path $Root 'AIVE_STABLE_PILOT_0.5.3_SIGNED.zxp'
$Upia = Join-Path $env:ProgramFiles 'Common Files\Adobe\Adobe Desktop Common\RemoteComponents\UPI\UnifiedPluginInstallerAgent\UnifiedPluginInstallerAgent.exe'
$State = Join-Path $env:LOCALAPPDATA 'AIVE-Stable-Pilot'
$Signer = Join-Path $State 'toolcache\ZXPSignCmd.exe'
$Cert = Join-Path $State 'signing\aive-stable-pilot.p12'
$ProtectedPass = Join-Path $State 'signing\password.dpapi'
$SourceHashes = Join-Path $Root 'EXTENSION_SHA256SUMS.txt'

function Fatal([string]$Message) { throw $Message }
function Hash([string]$File) { return (Get-FileHash -LiteralPath $File -Algorithm SHA256).Hash.ToLowerInvariant() }
function LastCode([string]$Stage) {
    if ($LASTEXITCODE -ne 0) { Fatal "$Stage FAILED: exit code $LASTEXITCODE" }
}
try {
    Write-Host "AI Video Editor STABLE PILOT 0.5.3 - PC PERSONAL" -ForegroundColor Cyan
    Write-Host 'Nu se solicita automat drepturi de administrator si nu se modifica Registry.'
    if (-not (Test-Path -LiteralPath $Manifest -PathType Leaf)) { Fatal 'Sursa extensiei lipseste.' }
    if (-not (Test-Path -LiteralPath $SourceHashes -PathType Leaf)) { Fatal 'Lista de integritate lipseste.' }
    if (-not $env:LOCALAPPDATA) { Fatal 'LOCALAPPDATA nu este disponibil.' }
    if (Get-Process -Name 'Adobe Premiere Pro' -ErrorAction SilentlyContinue) { Fatal 'Inchide Premiere Pro inainte de instalare.' }
    $manifestXml = [xml](Get-Content -LiteralPath $Manifest -Raw)
    if ($manifestXml.ExtensionManifest.ExtensionBundleId -ne 'com.aive.stable.pilot' -or
        $manifestXml.ExtensionManifest.ExtensionBundleVersion -ne '0.5.3') { Fatal 'Manifestul nu corespunde versiunii aprobate.' }
    if (Get-ChildItem -LiteralPath $Ext -Recurse -Force -Attributes ReparsePoint -ErrorAction SilentlyContinue) {
        Fatal 'Directorul extensiei contine symlink-uri. Refuz instalarea.'
    }
    Write-Host 'Verific sursele extensiei...'
    $verified = 0
    foreach ($line in Get-Content -LiteralPath $SourceHashes) {
        if (-not $line.Trim()) { continue }
        if ($line -notmatch '^([0-9a-f]{64})\s{2}(.+)$') { Fatal 'SHA256SUMS invalid.' }
        $expected = $Matches[1]
        $relative = $Matches[2]
        if ($relative.Contains('..') -or [IO.Path]::IsPathRooted($relative)) { Fatal 'Cale relativa invalida.' }
        $full = Join-Path $Ext $relative
        if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { Fatal "Sursa lipseste: $relative" }
        if ((Hash $full) -ne $expected) { Fatal "Integritate sursa FAILED: $relative" }
        $verified++
    }
    if ($verified -lt 6) { Fatal 'Lista de hash-uri incompleta.' }
    $fileCount = @(Get-ChildItem -LiteralPath $Ext -Recurse -File -Force).Count
    if ($fileCount -ne $verified) { Fatal "Directorul extensiei are $fileCount fisiere, dar sunt $verified hash-uri. Refuz fisierele suplimentare/nesemnate in registru." }
    Write-Host "PASS $verified surse SHA-256." -ForegroundColor Green
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Signer) | Out-Null
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Cert) | Out-Null
    if (-not (Test-Path -LiteralPath $Signer -PathType Leaf) -or (Hash $Signer) -ne $SignerHash) {
        Write-Host 'Descarc o singura data Adobe ZXPSignCmd oficial...'
        Invoke-WebRequest -Uri $SignerSource -UseBasicParsing -OutFile $Signer
    }
    if ((Hash $Signer) -ne $SignerHash) { Fatal 'Adobe signer SHA256 invalid! STOP.' }
    Write-Host 'PASS Adobe ZXPSignCmd SHA-256.' -ForegroundColor Green
    if ((Test-Path -LiteralPath $Cert) -xor (Test-Path -LiteralPath $ProtectedPass)) {
        Fatal 'Certificatul si parola securizata nu corespund; nu generez alt certificat peste cel vechi.'
    }
    if (-not (Test-Path -LiteralPath $Cert)) {
        # Certificate kept locally for subsequent updates. Password stored via Windows DPAPI (user scoped).
        $random = New-Object byte[] 36
        [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($random)
        $rawPassword = [Convert]::ToBase64String($random)
        $secret = ConvertTo-SecureString -String $rawPassword -AsPlainText -Force
        ConvertFrom-SecureString -SecureString $secret | Set-Content -LiteralPath $ProtectedPass -NoNewline
        & $Signer -selfSignedCert MD Chisinau AIVE AIVE-STABLE-PILOT $rawPassword $Cert -validityDays 730
        LastCode 'Create Adobe signing certificate'
        if (-not (Test-Path -LiteralPath $Cert -PathType Leaf)) { Fatal 'Certificat negenerat.' }
        Write-Host 'Certificat pilot creat local. PASTREAZA folderul de semnare.'
    } else {
        $secure = Get-Content -LiteralPath $ProtectedPass -Raw | ConvertTo-SecureString
        $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
        try { $rawPassword = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
    }
    if (Test-Path -LiteralPath $Output) { Remove-Item -LiteralPath $Output -Force }
    Write-Host 'Semnez pachetul STABLE PILOT...'
    & $Signer -sign $Ext $Output $Cert $rawPassword
    LastCode 'Adobe ZXPSignCmd sign'
    & $Signer -verify $Output
    LastCode 'Adobe ZXPSignCmd verify'
    Write-Host ('SIGNED ZXP SHA256: '+(Hash $Output)) -ForegroundColor Green
    $rawPassword = $null
    if (-not (Test-Path -LiteralPath $Upia -PathType Leaf)) {
        Write-Host ('Pachet semnat: '+$Output)
        Fatal 'Adobe UPIA nu este instalat in calea asteptata. Instalarea NU s-a efectuat.'
    }
    Write-Host 'Instalez prin utilitarul oficial Adobe UPIA, fara elevare...'
    & $Upia /install $Output
    LastCode 'Adobe UPIA install'
    Write-Host 'UPIA PASS (exit 0). Deschide Premiere 2026: Window > Extensions (Legacy) > AI Video Editor - STABLE PILOT.' -ForegroundColor Green
    # Keep an exact signed recovery package for safe in-panel updates.
    $Recovery = Join-Path $State 'recovery'
    New-Item -ItemType Directory -Force -Path $Recovery | Out-Null
    $RecoverFile = Join-Path $Recovery 'AIVE_STABLE_PILOT_0.5.3_SIGNED.zxp'
    Copy-Item -LiteralPath $Output -Destination $RecoverFile -Force
    $RecoverHash = Hash $RecoverFile
    $lastGood = Join-Path $Recovery 'last-good.json'
    @{ version='0.5.3'; sha256=$RecoverHash } | ConvertTo-Json | Set-Content -LiteralPath ($lastGood+'.tmp') -Encoding UTF8
    Move-Item -LiteralPath ($lastGood+'.tmp') -Destination $lastGood -Force
    Write-Host 'Copia semnata pentru rollback a fost salvata in LOCALAPPDATA.' -ForegroundColor Green

    Write-Host 'Versiunea este CANDIDAT. Nu utiliza proiecte de productie pana la testul LIVE.' -ForegroundColor Yellow
    exit 0
} catch {
    Write-Host ('STOP: '+$_.Exception.Message) -ForegroundColor Red
    Write-Host 'Nu modifica Registry sau Developer Mode. Raporteaza mesajul de eroare.'
    exit 1
}
