@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo AI Video Editor STABLE PILOT 0.5.0 - DOAR PC PERSONAL.
echo Semnare Adobe locala, verificare integritate, instalare UPIA.
powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0INSTALL_PERSONAL.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo Instalarea NU este confirmata. Raporteaza eroarea de mai sus.
pause
exit /b %RC%
