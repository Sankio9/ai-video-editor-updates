# AIVE STABLE PILOT — on-demand update worker copied from the signed extension.
# Runs only after user explicitly clicks 'Actualizeaza'. Exits if Premiere never closes.
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$StageRoot,
  [Parameter(Mandatory=$true)][string]$TargetVersion
)
$ErrorActionPreference='Stop'
$state=Join-Path $env:LOCALAPPDATA 'AIVE-Stable-Pilot'
$statusFile=Join-Path $state 'update-status.json'
$recovery=Join-Path $state 'recovery'
$cert=Join-Path $state 'signing\aive-stable-pilot.p12'
$pass=Join-Path $state 'signing\password.dpapi'
$upia=Join-Path $env:ProgramFiles 'Common Files\Adobe\Adobe Desktop Common\RemoteComponents\UPI\UnifiedPluginInstallerAgent\UnifiedPluginInstallerAgent.exe'
$oldVersion=''
$oldZxp=''
function PutStatus([string]$Status,[string]$Message) {
  New-Item -ItemType Directory -Force -Path $state | Out-Null
  $obj=@{version=$TargetVersion;status=$Status;message=$Message;at=(Get-Date).ToUniversalTime().ToString('o')}
  $temp=$statusFile+'.tmp';$obj|ConvertTo-Json -Compress|Set-Content -LiteralPath $temp -Encoding UTF8
  Move-Item -LiteralPath $temp -Destination $statusFile -Force
}
function StopWith([string]$Message){throw $Message}
function FileHash([string]$p){return (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
try {
  if ($TargetVersion -notmatch '^\d{1,3}\.\d{1,3}\.\d{1,3}$') {StopWith 'Versiune tinta invalida.'}
  $StageRoot=(Resolve-Path -LiteralPath $StageRoot).ProviderPath
  $expectedStage=Join-Path (Join-Path $state 'updates') ('v'+$TargetVersion)
  if (-not ([string]::Equals($StageRoot,$expectedStage,[StringComparison]::OrdinalIgnoreCase))) {StopWith 'Director de update neautorizat.'}
  $hashFile=Join-Path $StageRoot 'PACKAGE_SHA256.txt'
  $sourceFile=Join-Path $StageRoot 'EXTENSION_SHA256SUMS.txt'
  $installer=Join-Path $StageRoot 'INSTALL_PERSONAL.ps1'
  $manifest=Join-Path $StageRoot 'extension\CSXS\manifest.xml'
  if (!(Test-Path -LiteralPath $hashFile) -or !(Test-Path -LiteralPath $sourceFile) -or !(Test-Path -LiteralPath $installer) -or !(Test-Path -LiteralPath $manifest)) {StopWith 'Actualizarea pregatita este incompleta.'}
  $expected=(Get-Content -LiteralPath $hashFile -Raw).Trim()
  if ($expected -notmatch '^[0-9a-f]{64}$') {StopWith 'Lipseste hash-ul pachetului.'}
  $x=[xml](Get-Content -LiteralPath $manifest -Raw)
  if ($x.ExtensionManifest.ExtensionBundleId -ne 'com.aive.stable.pilot' -or $x.ExtensionManifest.ExtensionBundleVersion -ne $TargetVersion) {StopWith 'Manifestul nu corespunde canalului STABLE PILOT.'}
  if (!(Test-Path -LiteralPath $cert -PathType Leaf) -or !(Test-Path -LiteralPath $pass -PathType Leaf)) {StopWith 'Certificatul local nu exista. Foloseste instalatorul de recuperare; nu creez unul nou automat.'}
  if (!(Test-Path -LiteralPath $upia -PathType Leaf)) {StopWith 'Adobe UPIA este indisponibil.'}
  # Perform an independent integrity verification immediately before Adobe installation.
  $expectedLines=Get-Content -LiteralPath $sourceFile
  $checked=0
  foreach($line in $expectedLines){
    if(-not $line.Trim()){continue}
    if($line -notmatch '^([a-f0-9]{64})  (.+)$'){StopWith 'Lista hash invalid.'}
    $hash=$Matches[1];$rel=$Matches[2]
    if($rel.Contains('..') -or [IO.Path]::IsPathRooted($rel)){StopWith 'Cale de integritate invalida.'}
    $p=Join-Path (Join-Path $StageRoot 'extension') $rel
    if(!(Test-Path -LiteralPath $p -PathType Leaf) -or (FileHash $p) -ne $hash){StopWith ('SHA invalid '+$rel)}
    $checked++
  }
  $actualCount=@(Get-ChildItem -LiteralPath (Join-Path $StageRoot 'extension') -Recurse -File).Count
  if($checked -lt 9 -or $checked -ne $actualCount){StopWith 'Inventarul extensiei nu corespunde registrului SHA.'}
  PutStatus 'WAITING_FOR_PREMIERE_EXIT' 'Actualizarea este pregatita. Inchide Premiere pentru instalarea prin Adobe UPIA.'
  $limit=(Get-Date).AddHours(2)
  while(Get-Process -Name 'Adobe Premiere Pro' -ErrorAction SilentlyContinue){
    if((Get-Date) -gt $limit){StopWith 'Premiere nu a fost inchis. Actualizarea a fost anulata fara modificari.'}
    Start-Sleep -Seconds 3
  }
  Start-Sleep -Seconds 3
  if(Get-Process -Name 'Adobe Premiere Pro' -ErrorAction SilentlyContinue){StopWith 'Premiere a fost redeschis; instalarea a fost anulata.'}
  PutStatus 'INSTALLING' 'Adobe UPIA instaleaza actualizarea semnata local.'
  $last=Join-Path $recovery 'last-good.json'
  if(Test-Path -LiteralPath $last){
    $prev=Get-Content -LiteralPath $last -Raw|ConvertFrom-Json
    if($prev.version -match '^\d{1,3}\.\d{1,3}\.\d{1,3}$' -and $prev.sha256 -match '^[0-9a-f]{64}$'){
      $candidate=Join-Path $recovery ('AIVE_STABLE_PILOT_'+$prev.version+'_SIGNED.zxp')
      if((Test-Path -LiteralPath $candidate -PathType Leaf) -and (FileHash $candidate) -eq $prev.sha256){$oldZxp=$candidate;$oldVersion=$prev.version}
    }
  }
  if(-not $oldZxp){StopWith 'Copia semnata anterioara nu este disponibila. Refuz actualizarea fara posibilitate de rollback.'}
  $powershell=Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
  if(!(Test-Path -LiteralPath $powershell -PathType Leaf)){StopWith 'PowerShell Windows lipsește.'}
  & $powershell -NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -File $installer
  if($LASTEXITCODE -ne 0){StopWith ('Adobe UPIA / semnare FAILED: '+$LASTEXITCODE)}
  $newZxp=Join-Path $StageRoot ('AIVE_STABLE_PILOT_'+$TargetVersion+'_SIGNED.zxp')
  if(!(Test-Path -LiteralPath $newZxp -PathType Leaf)){StopWith 'ZXP semnat nou lipseste.'}
  New-Item -ItemType Directory -Force -Path $recovery | Out-Null
  $newHash=FileHash $newZxp
  Copy-Item -LiteralPath $newZxp -Destination (Join-Path $recovery ('AIVE_STABLE_PILOT_'+$TargetVersion+'_SIGNED.zxp')) -Force
  $tmp=Join-Path $recovery 'last-good.json.tmp'
  @{version=$TargetVersion;sha256=$newHash}|ConvertTo-Json|Set-Content -LiteralPath $tmp -Encoding UTF8
  Move-Item -LiteralPath $tmp -Destination $last -Force
  PutStatus 'SUCCESS' 'Actualizare instalata. Reporneste Premiere.'
  exit 0
} catch {
  $reason=$_.Exception.Message
  if($oldZxp -and $oldVersion){
    try {
      PutStatus 'RESTORING' ('Actualizarea a esuat: '+$reason+'. Incerc recuperarea '+$oldVersion+'.')
      & $upia /install $oldZxp
      if($LASTEXITCODE -eq 0){PutStatus 'ROLLED_BACK' ('Actualizarea a esuat, versiunea '+$oldVersion+' a fost reinstalata: '+$reason);exit 1}
      $reason+='; UPIA rollback exit '+$LASTEXITCODE
    } catch {$reason+='; rollback exception '+$_.Exception.Message}
    PutStatus 'ROLLBACK_FAILED' ($reason+'. Nu deschide proiecte de productie.')
  } else {PutStatus 'FAILED' $reason}
  exit 1
}
