@echo off
echo This installation is run by the verified AIVE OTA worker.
echo Do not execute it manually; use the button inside AIVE.
exit /b 1
