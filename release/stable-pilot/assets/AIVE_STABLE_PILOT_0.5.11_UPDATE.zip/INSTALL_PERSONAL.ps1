# AIVE STABLE PILOT 0.5.11 — offline signing + Adobe UPIA install.
# Called only by the existing AIVE verified on-demand update worker.
# Never stores certificates, passwords or DOCX outside the existing local signing profile.
[CmdletBinding()]
param([switch]$SignOnly)
$ErrorActionPreference='Stop'
$Version='0.5.11'
$State=Join-Path $env:LOCALAPPDATA 'AIVE-Stable-Pilot'
$Root=$PSScriptRoot
$Extension=Join-Path $Root 'extension'
$Manifest=Join-Path $Extension 'CSXS\manifest.xml'
$Register=Join-Path $Root 'EXTENSION_SHA256SUMS.txt'
$Certificate=Join-Path $State 'signing\aive-stable-pilot.p12'
$PasswordFile=Join-Path $State 'signing\password.dpapi'
$Zxp=Join-Path $Root ('AIVE_STABLE_PILOT_'+$Version+'_SIGNED.zxp')
$Upia=Join-Path $env:ProgramFiles 'Common Files\Adobe\Adobe Desktop Common\RemoteComponents\UPI\UnifiedPluginInstallerAgent\UnifiedPluginInstallerAgent.exe'
function Abort([string]$message){throw ('STOP: '+$message)}
function Digest([string]$file){return (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant()}
try {
 if(Get-Process -Name 'Adobe Premiere Pro' -ErrorAction SilentlyContinue){Abort 'Inchide Premiere Pro complet inainte de instalare.'}
 if(!(Test-Path -LiteralPath $Manifest -PathType Leaf)){Abort 'Manifest lipsa.'}
 $mx=[xml](Get-Content -LiteralPath $Manifest -Raw -Encoding UTF8)
 if($mx.ExtensionManifest.ExtensionBundleId -ne 'com.aive.stable.pilot' -or $mx.ExtensionManifest.ExtensionBundleVersion -ne '0.5.11'){
  Abort 'Manifestul nu corespunde versiunii 0.5.11.'
 }
 if(!(Test-Path -LiteralPath $Register -PathType Leaf)){Abort 'Registrul SHA lipseste.'}
 $seen=@{}
 foreach($line in @(Get-Content -LiteralPath $Register -Encoding UTF8)){
  if(!$line.Trim()){continue}
  if($line -notmatch '^([a-f0-9]{64})  ([^\r\n]+)$'){Abort 'Inregistrare SHA invalida.'}
  $hash=$Matches[1];$rel=$Matches[2]
  if($rel.Contains('..') -or [IO.Path]::IsPathRooted($rel) -or $seen.ContainsKey($rel)){Abort 'Cale SHA neautorizata.'}
  $f=Join-Path $Extension ($rel.Replace('/','\'))
  if(!(Test-Path -LiteralPath $f -PathType Leaf) -or (Digest $f) -ne $hash){Abort ('Fisier modificat: '+$rel)}
  $seen[$rel]=$true
 }
 if($seen.Count -ne 11 -or @(Get-ChildItem -LiteralPath $Extension -File -Recurse).Count -ne $seen.Count){Abort 'Numar fisiere neasteptat.'}
 if(!(Test-Path -LiteralPath $Certificate -PathType Leaf) -or !(Test-Path -LiteralPath $PasswordFile -PathType Leaf)){
  Abort 'Lipseste certificatul local de semnare sau parola DPAPI. Nicio modificare.'
 }
 if(-not $SignOnly -and !(Test-Path -LiteralPath $Upia -PathType Leaf)){Abort 'Adobe UnifiedPluginInstallerAgent.exe lipseste.'}
 # Secure Adobe signer bootstrap: official, immutable source and SHA-256 pin.
 # Network access occurs only during an explicit AIVE update; no elevated installer.
 $officialSha='ffc2223167225ce61d024eb463fc5ad1a1be16133f99ef334a646f7311916c98'
 $signer=$null
 $candidates=@(
  (Join-Path $State 'tools\ZXPSignCmd.exe'),
  (Join-Path $State 'signing\ZXPSignCmd.exe'),
  (Join-Path $State 'ZXPSignCmd.exe'),
  (Join-Path $env:LOCALAPPDATA 'ZXPSignCmd\ZXPSignCmd.exe')
 )
 foreach($p in $candidates){
  if((Test-Path -LiteralPath $p -PathType Leaf) -and (Digest $p) -eq $officialSha){ $signer=$p; break }
 }
 if(!$signer){
  $cache=Join-Path $State 'tools\ZXPSignCmd.exe'
  $temp=$cache+'.download'
  $source='https://raw.githubusercontent.com/Adobe-CEP/CEP-Resources/ab5e4e3e53a42fad08e1225a22a991bb1ffe73f6/ZXPSignCMD/4.1.3/x64/ZXPSignCmd.exe'
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $cache) | Out-Null
  try{
   if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force}
   [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
   Invoke-WebRequest -UseBasicParsing -Uri $source -OutFile $temp -TimeoutSec 60
   if(!(Test-Path -LiteralPath $temp -PathType Leaf) -or (Digest $temp) -ne $officialSha){
    Abort 'Semnatorul Adobe descarcat nu corespunde SHA-256 oficial. Nu execut.'
   }
   Move-Item -LiteralPath $temp -Destination $cache -Force
   $signer=$cache
  }catch{
   Abort ('Nu pot obtine semnatorul oficial Adobe: '+$_.Exception.Message)
  }finally{
   if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue}
  }
 }
 if(!(Test-Path -LiteralPath $signer -PathType Leaf) -or (Digest $signer) -ne $officialSha){Abort 'ZXPSignCmd Adobe 4.1.3 nu a trecut verificarea de integritate.'}
 $secret=Get-Content -LiteralPath $PasswordFile -Raw -Encoding UTF8 | ConvertTo-SecureString
 $ptr=[IntPtr]::Zero
 try{
  $ptr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
  $plaintext=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
  if(!$plaintext){Abort 'Parola locală de semnare nu poate fi citita.'}
  if(Test-Path -LiteralPath $Zxp){Remove-Item -LiteralPath $Zxp -Force}
  & $signer -sign $Extension $Zxp $Certificate $plaintext
  if($LASTEXITCODE -ne 0){Abort ('Semnarea Adobe ZXP a esuat: '+$LASTEXITCODE)}
 } finally{
  if($ptr -ne [IntPtr]::Zero){[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)}
  $plaintext=$null
 }
 if(!(Test-Path -LiteralPath $Zxp -PathType Leaf) -or (Get-Item -LiteralPath $Zxp).Length -lt 10000){Abort 'ZXP semnat nu este valid ca dimensiune.'}
 # Signing completed and local signer/certificate checks passed before invoking Adobe UPIA.
 if($SignOnly){Write-Host 'PASS: ZXP signed via verified Adobe tool; UPIA not executed.';exit 0}
 & $Upia /install $Zxp
 if($LASTEXITCODE -ne 0){Abort ('Adobe UPIA a respins extensia: '+$LASTEXITCODE)}
 Write-Host 'PASS: Adobe UPIA a instalat AIVE STABLE PILOT 0.5.11.'
 exit 0
}catch{
 Write-Error $_.Exception.Message
 exit 1
}
