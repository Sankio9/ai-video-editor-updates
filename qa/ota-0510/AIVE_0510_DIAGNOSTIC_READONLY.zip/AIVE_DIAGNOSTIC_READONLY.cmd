@echo off
setlocal
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" (
  echo Windows PowerShell not found.
  pause
  exit /b 1
)
"%PS%" -NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -File "%~dp0AIVE_DIAGNOSTIC_READONLY.ps1"
if errorlevel 1 (
  echo Diagnostic failed. Nothing was installed.
)
echo.
pause
