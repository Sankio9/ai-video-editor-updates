﻿# AIVE 0.5.10 - read-only OTA diagnostics for Windows PowerShell 5.1
# This script NEVER calls UPIA, ZXPSignCmd, the installer or the updater.
# It checks file metadata and reads recent Adobe UPIA log entries.
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
try {
    $desktop = [Environment]::GetFolderPath('Desktop')
    if ([string]::IsNullOrWhiteSpace($desktop) -or !(Test-Path -LiteralPath $desktop)) { $desktop = $env:TEMP }
    $report = Join-Path $desktop 'AIVE_0510_DIAGNOSTIC_READONLY.txt'
    $state = Join-Path $env:LOCALAPPDATA 'AIVE-Stable-Pilot'
    $stage = Join-Path $state 'updates\v0.5.10'
    $logs = Join-Path $env:APPDATA 'Adobe\UPI\Log'
    $upia = Join-Path $env:ProgramFiles 'Common Files\Adobe\Adobe Desktop Common\RemoteComponents\UPI\UnifiedPluginInstallerAgent\UnifiedPluginInstallerAgent.exe'
    $now = Get-Date
    $lines = New-Object 'System.Collections.Generic.List[string]'
    function Add([string]$line) { [void]$lines.Add($line) }
    function Exists([string]$label, [string]$path) {
        if (Test-Path -LiteralPath $path -PathType Leaf) {
            $item = Get-Item -LiteralPath $path
            Add ('[PRESENT] '+$label+' | size='+$item.Length+' bytes | modified='+$item.LastWriteTime.ToString('yyyy-MM-dd HH:mm'))
            return $true
        }
        Add ('[MISSING] '+$label)
        return $false
    }
    Add 'AIVE 0.5.10 - SAFE READ-ONLY DIAGNOSTIC'
    Add ('Generated: '+$now.ToString('yyyy-MM-dd HH:mm:ss'))
    Add 'No files of the installed AIVE / Adobe were changed.'
    Add 'This report does not contain certificate, password, DPAPI contents or DOCX text.'
    Add ''
    Add '=== AIVE status ==='
    $status = Join-Path $state 'update-status.json'
    if (Test-Path -LiteralPath $status -PathType Leaf) {
        try {
            $v = Get-Content -LiteralPath $status -Raw -Encoding UTF8 | ConvertFrom-Json
            Add ('Latest update: '+[string]$v.version)
            Add ('Status: '+[string]$v.status)
            Add ('Message: '+[string]$v.message)
            Add ('Updated: '+[string]$v.at)
        } catch { Add ('Status file is not readable JSON: '+$_.Exception.GetType().Name) }
    } else { Add 'AIVE update-status.json not found.' }
    $last = Join-Path $state 'recovery\last-good.json'
    if (Test-Path -LiteralPath $last -PathType Leaf) {
        try {
            $v = Get-Content -LiteralPath $last -Raw -Encoding UTF8 | ConvertFrom-Json
            Add ('Last-good version: '+[string]$v.version)
            Add ('Last-good signed package hash available: '+[bool]($v.sha256 -match '^[a-f0-9]{64}$'))
        } catch { Add 'Last-good marker cannot be parsed.' }
    } else { Add 'Last-good marker not found.' }
    Add ''
    Add '=== Installed/staged files: presence only ==='
    [void](Exists 'Adobe UPIA executable' $upia)
    [void](Exists 'AIVE signing certificate .p12' (Join-Path $state 'signing\aive-stable-pilot.p12'))
    [void](Exists 'AIVE encrypted signing password .dpapi' (Join-Path $state 'signing\password.dpapi'))
    $candidates = @(
        (Join-Path $state 'signing\ZXPSignCmd.exe'),
        (Join-Path $state 'tools\ZXPSignCmd.exe'),
        (Join-Path $state 'ZXPSignCmd.exe'),
        (Join-Path $env:LOCALAPPDATA 'ZXPSignCmd\ZXPSignCmd.exe')
    )
    $signed = $false
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            [void](Exists 'ZXPSignCmd.exe in AIVE location' $candidate)
            $signed = $true
            break
        }
    }
    if (!$signed) {
        $cmd = Get-Command 'ZXPSignCmd.exe' -ErrorAction SilentlyContinue
        if ($cmd -and $cmd.Source) { Add '[PRESENT] ZXPSignCmd.exe on PATH'; $signed = $true }
    }
    if (!$signed) { Add '[MISSING] ZXPSignCmd.exe - none of the installer-supported locations/PATH found.' }
    $newZxp = Join-Path $stage 'AIVE_STABLE_PILOT_0.5.10_SIGNED.zxp'
    $hasZxp = Exists '0.5.10 signed ZXP in staged folder' $newZxp
    [void](Exists '0.5.10 staged installer' (Join-Path $stage 'INSTALL_PERSONAL.ps1'))
    [void](Exists '0.5.10 staged manifest' (Join-Path $stage 'extension\CSXS\manifest.xml'))
    [void](Exists '0.5.9 signed rollback ZXP' (Join-Path $state 'recovery\AIVE_STABLE_PILOT_0.5.9_SIGNED.zxp'))
    Add ''
    Add '=== Initial non-destructive interpretation ==='
    if ($hasZxp) { Add 'A 0.5.10 ZXP exists. Signing might have completed; inspect Adobe UPIA logs for the install error.' }
    else { Add 'No 0.5.10 signed ZXP found. The failure may have occurred during preflight or signing.' }
    Add 'Code 1 alone does not identify the failing step.'
    Add ''
    Add '=== Recent Adobe UPIA log excerpts (error-relevant only) ==='
    if (Test-Path -LiteralPath $logs -PathType Container) {
        $files = @(Get-ChildItem -LiteralPath $logs -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 4)
        if ($files.Count -eq 0) { Add 'No UPIA log files found.' }
        foreach($file in $files){
            Add ('Log: '+$file.Name+' | modified='+$file.LastWriteTime.ToString('yyyy-MM-dd HH:mm'))
            try {
                $tail = @(Get-Content -LiteralPath $file.FullName -Tail 450 -ErrorAction Stop)
                $filtered = @($tail | Where-Object { $_ -match '(?i)error|failed|failure|signature|signing|install|zxp|\-402|\-506|\-631|\-459|aive|stable.pilot' } | Select-Object -Last 36)
                if ($filtered.Count -eq 0) { Add '(no error-related lines in last 450 log lines)' }
                foreach($raw in $filtered){
                    $line=[string]$raw
                    # Remove user-specific paths, emails, query strings and extremely long lines.
                    $line=[regex]::Replace($line,'(?i)C:\\Users\\[^\\\s\"''<>]+','C:\Users\[USER]')
                    $line=[regex]::Replace($line,'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}','[EMAIL]')
                    $line=[regex]::Replace($line,'(?i)(token|password|secret|api.key|access.key)\s*[:=]\s*[^\s,;]+','$1=[REDACTED]')
                    if ($line.Length -gt 480) { $line=$line.Substring(0,480)+' ...[truncated]' }
                    Add $line
                }
            } catch { Add ('Unable to read log: '+$_.Exception.GetType().Name) }
        }
    } else { Add 'No Adobe UPIA log directory found.' }
    Add ''
    Add '=== End ==='
    Add 'Before sharing, review the log excerpts for information you consider private.'
    [System.IO.File]::WriteAllLines($report, $lines.ToArray(), (New-Object System.Text.UTF8Encoding($true)))
    Write-Host ('DONE: '+$report)
    Write-Host 'No installation, signing, rollback or AIVE file replacement executed.'
    try { Start-Process -FilePath 'notepad.exe' -ArgumentList ('"'+$report+'"') -ErrorAction Stop } catch {}
} catch {
    Write-Host ('DIAGNOSTIC_ERROR: '+$_.Exception.Message)
    exit 1
}
