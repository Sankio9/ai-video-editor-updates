AIVE 0.5.10 — OTA read-only diagnostic

1. Unzip the archive.
2. Double-click AIVE_DIAGNOSTIC_READONLY.cmd. No administrator permission needed.
3. A report will appear in Notepad and be saved to Desktop as AIVE_0510_DIAGNOSTIC_READONLY.txt.
4. Read the report, then upload only this TXT to the chat.

Safety:
- No AIVE or Adobe files are changed.
- No Adobe UPIA, ZXPSignCmd, installer, updater, or rollback is invoked.
- Does not read certificate contents, DPAPI password, or DOCX documents.
- Reads recent error-relevant Adobe UPIA log lines and redacts basic paths/emails/secrets. Review before sharing.

The AIVE 0.5.10 OTA was withdrawn; do not retry that update.
